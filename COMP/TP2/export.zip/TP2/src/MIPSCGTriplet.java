/**
 * For MIPS code generator. Don't care.
 * 
 * @param <T>
 */
public class MIPSCGTriplet<T> {
	T t1, t2, t3;

	public MIPSCGTriplet(T t1, T t2, T t3) {
		this.t1 = t1;
		this.t2 = t2;
		this.t3 = t3;
	}

	public T get1() {
		return t1;
	}

	public T get2() {
		return t2;
	}

	public T get3() {
		return t3;
	}

}
